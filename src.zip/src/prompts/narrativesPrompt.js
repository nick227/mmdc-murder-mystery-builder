export function buildNarrativesPrompt({ storyBlurb, solution, trails, playerCount, characters }) {
  return {
    system: [
      'You generate competing suspect narratives for a murder mystery.',
      'These are social stories and vibes, not forensic evidence.',
      'Exactly one is true, but all three must feel viable.',
      'Each narrative must center on a different suspect.',
      'Do not invent physical evidence or new objects.',
      'Do not create exact timelines.',
      'Suspects must come from the playable characters provided.',
      'The selected true_narrative must match solution.killer.'
    ].join(' '),
    user: `
Create 3 competing suspect narratives for this mystery.

Public blurb:
${storyBlurb}

Hidden solution:
${JSON.stringify(solution || {}, null, 2)}

Breadcrumb scaffolding:
${JSON.stringify(trails, null, 2)}

Playable characters:
${JSON.stringify(characters || [], null, 2)}

Player count:
${playerCount}

Requirements:
- narrative a, b, c must each center on a different suspect
- each needs motive and opportunity
- each needs suspicious social behavior, vague movement, or emotional reactions
- each needs 1 to 3 contradiction hooks
- exactly one narrative is true
- keep all three debatable and coherent
- do not write direct answer-key language
- do not invent physical evidence, forensic proof, or new objects
- suspects must be selected from the playable characters above
- the narrative whose suspect matches solution.killer must be the selected true_narrative
- the killer narrative must not describe them as innocent, excluded, or a red herring
- non-killer narratives may sound plausible, but must remain socially suspicious rather than mechanically proven

Return:
{
  "narratives": {
    "a": {...},
    "b": {...},
    "c": {...},
    "true_narrative": "a"
  }
}
`.trim()
  };
}
