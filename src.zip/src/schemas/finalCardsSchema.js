const finalCardSchema = {
  type: 'object',
  additionalProperties: false,
  required: [
    'card_id',
    'card_type',
    'card_title',
    'card_contents',
    'act',
    'linked_character_id'
  ],
  properties: {
    card_id: { type: 'string' },
    card_type: { type: 'string' },
    card_title: { type: 'string' },
    card_contents: { type: 'string' },
    act: { type: 'integer', enum: [1, 2, 3] },
    linked_character_id: { type: ['string', 'null'] },
    trail_role: {
      type: ['string', 'null'],
      enum: ['red_herring', 'ambiguous', 'killer_aligned', null]
    }
  }
};

export const finalCardsSchema = {
  type: 'object',
  additionalProperties: false,
  required: ['cards'],
  properties: {
    cards: {
      type: 'array',
      items: finalCardSchema
    }
  }
};
