import crypto from 'node:crypto';

export function getCardsByType(cards = [], type) {
  return (Array.isArray(cards) ? cards : []).filter((card) => card?.card_type === type);
}

export function getCharacterCards(cards = []) {
  return getCardsByType(cards, 'character');
}

export function mergeCardMetadata(previousCards = [], nextCards = []) {
  return (Array.isArray(nextCards) ? nextCards : []).map((card, index) => {
    const previous = previousCards[index] || {};
    const merged = {
      ...card,
      card_id: card?.card_id || previous.card_id || crypto.randomUUID()
    };

    if (card?.linked_character_id !== undefined || previous.linked_character_id !== undefined) {
      merged.linked_character_id = card?.linked_character_id ?? previous.linked_character_id;
    }

    if (card?.linked_character_index !== undefined || previous.linked_character_index !== undefined) {
      merged.linked_character_index = card?.linked_character_index ?? previous.linked_character_index;
    }

    if (card?.linked_character !== undefined || previous.linked_character !== undefined) {
      merged.linked_character = card?.linked_character ?? previous.linked_character;
    }

    if (card?.trail_role !== undefined || previous.trail_role !== undefined) {
      merged.trail_role = card?.trail_role ?? previous.trail_role;
    }

    return merged;
  });
}

export function pushCards(context, type, entries) {
  if (!context.cards) {
    context.cards = [];
  }

  const normalized = entries.map((e, i) => {
    const card = {
      card_id: e.card_id || crypto.randomUUID(),
      card_type: type,
      card_title: String(e.card_title || '').trim(),
      card_contents: String(e.card_contents || '').trim(),
      act: (e.act === 1 || e.act === 2 || e.act === 3)
        ? e.act
        : ((i % 3) + 1)
    };

    if (e.linked_character !== undefined) {
      card.linked_character = e.linked_character;
    }
    if (e.linked_character_index !== undefined) {
      card.linked_character_index = e.linked_character_index;
    }
    if (e.linked_character_id !== undefined) {
      card.linked_character_id = e.linked_character_id;
    }
    if (e.trail_role !== undefined) {
      card.trail_role = e.trail_role;
    }

    return card;
  });

  context.cards.push(...normalized);
  return context;
}
