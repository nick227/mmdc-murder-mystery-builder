import { callJson } from '../llm/client.js';
import { buildFinalEditorPrompt } from '../prompts/finalEditorPrompt.js';
import { finalCardsSchema } from '../schemas/finalCardsSchema.js';
import { getStoryBlurb } from '../utils/context.js';
import { mergeCardMetadata } from '../utils/cards.js';

export async function finalEditorAgent(context) {
  const existingCards = Array.isArray(context.cards) ? context.cards : [];

  const prompt = buildFinalEditorPrompt({
    storyBlurb: getStoryBlurb(context),
    trails: context.trails,
    narratives: context.narratives,
    ambiguityNotes: context.ambiguity_notes,
    cards: existingCards
  });

  const result = await callJson({
    ...prompt,
    schemaName: 'final_cards',
    schema: finalCardsSchema
  });

  if (Array.isArray(result.cards)) {
    context.cards = mergeCardMetadata(existingCards, result.cards).map((c, i) => ({
      ...c,
      act:
        c.act === 1 || c.act === 2 || c.act === 3
          ? c.act
          : ((i % 3) + 1)
    }));
  }

  return context;
}
